from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
import products
import policyholders

class Payment:
    def __init__(self, payment_id, policyholder, product): #calling policyholder and product classes
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.product = product
        self.balance = Decimal('0.00')                       #initial payment balance 
        self.last_payment_date = None                        #date of last payment made
        self.next_payment_due = None                         #date of next payment due
        self.status = 'pending'                              #payment status: pending, paid
        self.penalty_total = Decimal('0.00')                 #accumulated penalty for this payment

#deposit adds deposit amount to current balance
    def _to_decimal(self, amount):
        try:
            return Decimal(str(amount))
        except (InvalidOperation, TypeError):
            raise ValueError("Amount must be a number or numeric string")

    def deposit(self, amount):
        amt = self._to_decimal(amount)
        if amt <= 0:
            raise ValueError("Deposit amount must be positive")
        self.balance += amt
        print(f"{self.policyholder.id}: Deposit of {amt} made. Current balance: {self.balance}")

#make_payment removes product amount and penalty from balance, returns updated balance,
# payment date and due date if successful and returns payment failed if unsuccessful.

    def make_payment(self):
        payment_due= self.product.price + self.penalty_total
        if self.balance >= payment_due:
            self.balance -= payment_due
            self.last_payment_date = datetime.now()
            self.next_payment_due = self.last_payment_date + timedelta(days=30)
            self.status = 'paid'
            self.penalty_total = Decimal('0.00')  # reset penalties after successful payment
            print(f"{self.policyholder.id}: Payment of {payment_due} successful.")
            print(f"Next payment due: {self.next_payment_due.strftime('%Y-%m-%d')}")
        else:
            self.status = 'pending'
            print("{self.policyholder.id}: Payment failed. Insufficient balance. Please deposit more funds.")

    def get_balance(self):
        return self.balance

#reminder for next payment
    def send_reminder(self):
        if self.next_payment_due:
            print(f"Reminder: Next payment due on {self.next_payment_due.strftime('%Y-%m-%d')}")
        else:
            print("No payment has been made yet.")

#penalty on next payment
    def apply_penalty(self, penalty_amount):
        amt = self._to_decimal(penalty_amount)
        if amt <= 0:
            raise ValueError("Penalty must be positive")
        self.penalty_total += amt
        print(f"{self.policyholder.id}: Penalty of {amt} applied. Total penalty for this payment: {self.penalty_total}")