from decimal import Decimal, InvalidOperation

class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        try:
            self.price = Decimal(str(price))
        except (InvalidOperation, TypeError):
            raise ValueError("price must be numeric")
        self.status = 'active'

    def update_product(self, name=None, price=None):
        if name:
            self.name = name
        if price is not None:
            try:
                self.price = Decimal(str(price))
            except (InvalidOperation, TypeError):
                raise ValueError("price must be numeric")

    def suspend_product(self):
        self.status = 'suspended'