from policyholders import Policyholder
from products import Product
from payments import Payment

# Create policyholders
policyholder1 = Policyholder('PH001', 'Simisola Lawal')
policyholder2 = Policyholder('PH002', 'Bob James Anthony')

# Create products
product1 = Product('P01', 'Vehicle Insurance', 5000)
product2 = Product('P02', 'Health Insurance', 10000)
product3 = Product('P03', 'Jewelry Insurance', 8000)

# Create payments linked to policyholders and product
payment1 = Payment('PM01', policyholder1, product1)
payment2 = Payment('PM02', policyholder2, product2)

# Deposit and make payments relating to policyholder 1
payment1.deposit(5000)
payment1.make_payment()

# Deposit and make payments relating to policyholder 2
payment2.deposit(12000)
payment2.make_payment()

# Display account details
def display_account_details(payment):
    print("\n--- Account Details ---")
    print(f"Policyholder ID: {payment.policyholder.id}")
    print(f"Policyholder Name: {payment.policyholder.name}")
    print(f"Product: {payment.product.name}")
    print(f"Product Price: {payment.product.price}")
    print(f"Payment Status: {payment.status}")
    print(f"Balance: {payment.get_balance()}")
    if payment.last_payment_date:
        print(f"Last Payment Date: {payment.last_payment_date.strftime('%Y-%m-%d')}")
        print(f"Next Payment Due: {payment.next_payment_due.strftime('%Y-%m-%d')}")
    else:
        print("No payment made yet.")

# Show details for both policyholders
display_account_details(payment1)
display_account_details(payment2)