class Policyholder:
    def __init__(self, id, name):
        self.id = id
        self.name = name
        self.status = 'active'
        self.products = []
        self.payments = []

    def suspend(self):
        self.status = 'suspended'

    def reactivate(self):
        self.status = 'active'

    def display_details(self):
        print(f"ID: {self.id}, Name: {self.name}, Status: {self.status}")